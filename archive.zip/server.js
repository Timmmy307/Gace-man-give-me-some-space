// server.js — GACE Registrar backend (Cloudflare DNS + GitHub-backed encrypted accounts)
// Environment variables:
// ROOT_DOMAIN=gace.space
// CLOUDFLARE_ZONE_ID=your_zone_id
// CLOUDFLARE_API_TOKEN=your_api_token
// SESSION_SECRET=your_random_secret
// ENC_PASSPHRASE=strong_passphrase_for_encryption
// GITHUB_TOKEN=ghp_xxx (must have repo scope)
// GITHUB_REPO=owner/private-repo
// GITHUB_BRANCH=main

import express from "express";
import session from "express-session";
import bodyParser from "body-parser";
import fetch from "node-fetch";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import crypto from "crypto";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const ZONE_ID = process.env.CLOUDFLARE_ZONE_ID;
const CF_TOKEN = process.env.CLOUDFLARE_API_TOKEN;
const ROOT_DOMAIN = process.env.ROOT_DOMAIN || "gace.space";
const SESSION_SECRET = process.env.SESSION_SECRET || "supersecret";
const ENC_PASSPHRASE = process.env.ENC_PASSPHRASE || "dev-passphrase";
const GH_TOKEN = process.env.GITHUB_TOKEN || "";
const GH_REPO = process.env.GITHUB_REPO || "";
const GH_BRANCH = process.env.GITHUB_BRANCH || "main";

const GH_API = "https://api.github.com";
const ACCOUNTS_PATH = "data/accounts.json";
const LOG_PATH = "data/log.json";

function keyFromPass(pass) {
  return crypto.createHash("sha256").update(pass).digest();
}
function enc(plain) {
  const iv = crypto.randomBytes(12);
  const key = keyFromPass(ENC_PASSPHRASE);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const ct = Buffer.concat([cipher.update(String(plain), "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString("base64")}:${ct.toString("base64")}:${tag.toString("base64")}`;
}
function dec(payload) {
  try {
    const [v, ivB64, ctB64, tagB64] = String(payload).split(":");
    if (v !== "v1") throw new Error("bad_version");
    const iv = Buffer.from(ivB64, "base64");
    const ct = Buffer.from(ctB64, "base64");
    const tag = Buffer.from(tagB64, "base64");
    const key = keyFromPass(ENC_PASSPHRASE);
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAuthTag(tag);
    const pt = Buffer.concat([decipher.update(ct), decipher.final()]);
    return pt.toString("utf8");
  } catch {
    return null;
  }
}

async function ghGetJson(filePath, fallbackJson = "[]") {
  if (!GH_TOKEN || !GH_REPO) {
    // Fallback to local file
    const localPath = path.join(__dirname, filePath.replace(/^data\//, ""));
    if (!fs.existsSync(localPath)) return { json: JSON.parse(fallbackJson), sha: null, local: true, localPath };
    return { json: JSON.parse(fs.readFileSync(localPath, "utf8") || fallbackJson), sha: null, local: true, localPath };
  }
  const url = `${GH_API}/repos/${GH_REPO}/contents/${encodeURIComponent(filePath)}?ref=${encodeURIComponent(GH_BRANCH)}`;
  const r = await fetch(url, { headers: { Authorization: `Bearer ${GH_TOKEN}`, "Accept": "application/vnd.github+json" } });
  if (r.status === 404) return { json: JSON.parse(fallbackJson), sha: null };
  if (!r.ok) throw new Error(`GitHub GET ${filePath} failed: ${r.status}`);
  const d = await r.json();
  const content = Buffer.from(d.content || "", d.encoding || "base64").toString("utf8");
  return { json: JSON.parse(content || fallbackJson), sha: d.sha };
}
async function ghPutJson(filePath, data, message, sha = null) {
  const contentStr = JSON.stringify(data, null, 2) + "\n";
  if (!GH_TOKEN || !GH_REPO) {
    // Fallback to local file
    const localPath = path.join(__dirname, filePath.replace(/^data\//, ""));
    fs.writeFileSync(localPath, contentStr);
    return { ok: true, sha: null };
  }
  const url = `${GH_API}/repos/${GH_REPO}/contents/${encodeURIComponent(filePath)}`;
  const body = {
    message,
    content: Buffer.from(contentStr, "utf8").toString("base64"),
    branch: GH_BRANCH,
    ...(sha ? { sha } : {})
  };
  const r = await fetch(url, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${GH_TOKEN}`,
      "Accept": "application/vnd.github+json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
  if (!r.ok) throw new Error(`GitHub PUT ${filePath} failed: ${r.status}`);
  return await r.json();
}
async function getAccounts() {
  const { json } = await ghGetJson(ACCOUNTS_PATH, "[]");
  return Array.isArray(json) ? json : [];
}
async function saveAccounts(accounts, msg) {
  const cur = await ghGetJson(ACCOUNTS_PATH, "[]");
  return ghPutJson(ACCOUNTS_PATH, accounts, msg, cur.sha || null);
}
async function appendLog(event) {
  const { json, sha } = await ghGetJson(LOG_PATH, "[]");
  const arr = Array.isArray(json) ? json : [];
  arr.push({ ts: new Date().toISOString(), ...event });
  return ghPutJson(LOG_PATH, arr, `log: ${event.type}`, sha || null);
}
function validateLabel(label) {
  // 3-63, alnum and hyphen, no leading/trailing hyphen, ban short/abusive labels
  const banned = new Set(["nx", "xx", "xxx", "admin", "root", "mail", "api", "ns", "dns", "www"]);
  if (!label || typeof label !== "string") return false;
  const l = label.toLowerCase();
  if (l.startsWith("xn--")) return false; // disallow punycode-looking labels
  if (banned.has(l)) return false;
  if (!/^[a-z0-9]([a-z0-9-]{1,61}[a-z0-9])$/.test(l)) return false;
  return true;
}
function fqdnFromMaybe(input) {
  let x = String(input || "").trim().toLowerCase();
  if (!x) return null;
  if (!x.endsWith(`.${ROOT_DOMAIN}`)) {
    if (x.includes(".")) return null; // disallow other roots
    x = `${x}.${ROOT_DOMAIN}`;
  }
  return x;
}
function ownsName(user, fqdn) {
  const base = user?.baseDomain?.toLowerCase();
  if (!base || !fqdn) return false;
  return fqdn === base || fqdn.endsWith(`.${base}`);
}

// ----------- unchanged middleware -----------
app.use(bodyParser.json());
app.use(express.static(__dirname));
app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
  })
);

// ----------- CLOUDFLARE DNS HELPERS -----------
async function cfFetch(pathStr, opts = {}) {
  const r = await fetch(`https://api.cloudflare.com/client/v4/zones/${ZONE_ID}${pathStr}`, {
    headers: { Authorization: `Bearer ${CF_TOKEN}`, "Content-Type": "application/json" },
    ...opts,
  });
  return await r.json();
}

// ----------- AUTH ROUTES -----------
app.post("/api/signup", async (req, res) => {
  try {
    const { email, password, username, baseLabel } = req.body || {};
    if (!email || !password || !username || !baseLabel) {
      return res.status(400).json({ ok: false, msg: "missing_fields" });
    }
    if (!validateLabel(baseLabel)) return res.status(400).json({ ok: false, msg: "invalid_base_label" });

    const baseDomain = `${baseLabel.toLowerCase()}.${ROOT_DOMAIN}`;
    const accounts = await getAccounts();

    // Uniqueness checks (decrypt to compare)
    for (const a of accounts) {
      const e = dec(a.email);
      const u = dec(a.username);
      if (e && e.toLowerCase() === String(email).toLowerCase()) return res.status(400).json({ ok: false, msg: "email_taken" });
      if (u && u.toLowerCase() === String(username).toLowerCase()) return res.status(400).json({ ok: false, msg: "username_taken" });
      if (a.baseDomain && a.baseDomain.toLowerCase() === baseDomain) return res.status(400).json({ ok: false, msg: "base_taken" });
    }

    // Optional: ensure baseDomain not already present in DNS
    const cf = await cfFetch(`/dns_records?name=${encodeURIComponent(baseDomain)}`);
    if (cf?.result?.length) return res.status(400).json({ ok: false, msg: "base_conflict_dns" });

    const account = {
      id: crypto.randomUUID(),
      email: enc(email),
      username: enc(username),
      password: enc(password),
      baseDomain,
      records: [],
      createdAt: new Date().toISOString()
    };
    accounts.push(account);
    await saveAccounts(accounts, `accounts: signup ${username}`);
    await appendLog({ type: "signup", by: username, detail: { email, baseDomain } });

    // Provision ownership TXT for the base subdomain (parking/ownership like free registrars)
    try {
      const ownerTxt = {
        type: "TXT",
        name: baseDomain,
        content: `gace-owner=${username}`,
        ttl: 300,
        proxied: false
      };
      await cfFetch(`/dns_records`, { method: "POST", body: JSON.stringify(ownerTxt) });
      await appendLog({ type: "record_create", by: username, detail: { name: baseDomain, type: "TXT", content: "gace-owner=..." } });
    } catch (e) {
      // non-blocking
    }

    req.session.user = { email, username, baseDomain };
    res.json({ ok: true, user: req.session.user });
  } catch (err) {
    res.status(500).json({ ok: false, msg: err.message });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ ok: false, msg: "missing_fields" });
    const accounts = await getAccounts();
    const found = accounts.find(a => {
      const e = dec(a.email);
      return e && e.toLowerCase() === String(email).toLowerCase();
    });
    if (!found) return res.status(401).json({ ok: false, msg: "invalid_login" });
    const storedPw = dec(found.password);
    if (storedPw !== password) return res.status(401).json({ ok: false, msg: "invalid_login" });

    const username = dec(found.username);
    req.session.user = { email: dec(found.email) || email, username, baseDomain: found.baseDomain };
    await appendLog({ type: "login", by: username, detail: {} });
    res.json({ ok: true, user: req.session.user });
  } catch (err) {
    res.status(500).json({ ok: false, msg: err.message });
  }
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", (req, res) => {
  if (!req.session.user) return res.json({ ok: false });
  res.json({ ok: true, user: req.session.user });
});

// Public subdomain check — includes owner username if reserved/owned
app.get("/api/dns/check", async (req, res) => {
  try {
    const q = String(req.query.name || "").trim().toLowerCase();
    if (!q) return res.status(400).json({ ok: false, error: "missing_name" });
    // normalize to FQDN
    let name = q;
    if (!name.endsWith(`.${ROOT_DOMAIN}`)) {
      if (name.includes(".")) return res.status(400).json({ ok: false, error: "invalid_domain" });
      name = `${name}.${ROOT_DOMAIN}`;
    }
    const data = await cfFetch(`/dns_records?name=${encodeURIComponent(name)}`);
    const arr = data?.result || [];
    const live = {};
    for (const r of arr) {
      if (!live[r.type]) live[r.type] = [];
      live[r.type].push(r.content);
    }
    // find owner by baseDomain suffix
    const accounts = await getAccounts();
    let ownerUsername = null;
    for (const a of accounts) {
      const username = dec(a.username);
      if (name === a.baseDomain || name.endsWith(`.${a.baseDomain}`)) {
        ownerUsername = username;
        break;
      }
    }
    res.json({ ok: true, name, available: arr.length === 0, live, ownerUsername });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// ----------- DNS ROUTES -----------

// List DNS records (limited to user's baseDomain)
app.get("/api/records", async (req, res) => {
  if (!req.session.user) return res.status(401).json({ ok: false, msg: "Not logged in" });
  try {
    const all = await cfFetch(`/dns_records`);
    const base = req.session.user.baseDomain?.toLowerCase();
    const filtered = (all?.result || []).filter(r => base && (r.name.toLowerCase() === base || r.name.toLowerCase().endsWith(`.${base}`)));
    res.json({ success: true, result: filtered });
  } catch (err) {
    res.status(500).json({ ok: false, msg: err.message });
  }
});

// Create a new record (must be under user's baseDomain; force proxied=false)
app.post("/api/records", async (req, res) => {
  if (!req.session.user) return res.status(401).json({ ok: false, msg: "Not logged in" });
  try {
    const { type, name, content, ttl } = req.body || {};
    if (!type || !name) return res.status(400).json({ ok: false, msg: "missing_fields" });

    // Normalize name
    let fqdn = String(name).trim();
    if (fqdn === "@") fqdn = req.session.user.baseDomain;
    fqdn = fqdnFromMaybe(fqdn);
    if (!fqdn) return res.status(400).json({ ok: false, msg: "invalid_name" });
    if (!ownsName(req.session.user, fqdn)) return res.status(403).json({ ok: false, msg: "forbidden_outside_base" });

    // Build CF payload; ignore any `proxied`, enforce false
    const bodyObj = { type, name: fqdn };
    if (content !== undefined) bodyObj.content = content;
    if (ttl !== undefined) bodyObj.ttl = ttl;

    // Merge extras (priority, data, etc.)
    if (req.body.extra && typeof req.body.extra === "object") Object.assign(bodyObj, req.body.extra);
    for (const k of Object.keys(req.body)) {
      if (!["type", "name", "content", "ttl", "proxied", "extra"].includes(k)) bodyObj[k] = req.body[k];
    }
    bodyObj.proxied = false;

    const data = await cfFetch(`/dns_records`, { method: "POST", body: JSON.stringify(bodyObj) });
    if (data?.success) {
      // Track in account
      const accounts = await getAccounts();
      const acc = accounts.find(a => dec(a.email)?.toLowerCase() === req.session.user.email.toLowerCase());
      if (acc) {
        acc.records = acc.records || [];
        acc.records.push({ id: data.result?.id, name: fqdn, type, createdAt: new Date().toISOString() });
        await saveAccounts(accounts, `accounts: record create ${fqdn}`);
      }
      await appendLog({ type: "record_create", by: req.session.user.username, detail: { name: fqdn, type } });
    }
    res.json(data);
  } catch (err) {
    res.status(500).json({ ok: false, msg: err.message });
  }
});

// Update record (must be under user's baseDomain; force proxied=false)
app.patch("/api/records/:id", async (req, res) => {
  if (!req.session.user) return res.status(401).json({ ok: false, msg: "Not logged in" });
  try {
    // Fetch record to verify ownership
    const cur = await cfFetch(`/dns_records/${req.params.id}`);
    const rec = cur?.result;
    if (!rec) return res.status(404).json({ ok: false, msg: "not_found" });
    if (!ownsName(req.session.user, rec.name?.toLowerCase())) return res.status(403).json({ ok: false, msg: "forbidden_outside_base" });

    const bodyObj = {};
    for (const k of ["type", "name", "content", "ttl"]) if (req.body[k] !== undefined) bodyObj[k] = req.body[k];
    if (bodyObj.name) {
      bodyObj.name = fqdnFromMaybe(bodyObj.name === "@" ? req.session.user.baseDomain : bodyObj.name);
      if (!ownsName(req.session.user, bodyObj.name)) return res.status(403).json({ ok: false, msg: "forbidden_outside_base" });
    }
    if (req.body.extra && typeof req.body.extra === "object") Object.assign(bodyObj, req.body.extra);
    for (const k of Object.keys(req.body)) {
      if (!["type", "name", "content", "ttl", "proxied", "extra"].includes(k)) bodyObj[k] = req.body[k];
    }
    bodyObj.proxied = false;

    const data = await cfFetch(`/dns_records/${req.params.id}`, { method: "PATCH", body: JSON.stringify(bodyObj) });
    if (data?.success) await appendLog({ type: "record_update", by: req.session.user.username, detail: { id: req.params.id } });
    res.json(data);
  } catch (err) {
    res.status(500).json({ ok: false, msg: err.message });
  }
});

// Delete record (must be under user's baseDomain)
app.delete("/api/records/:id", async (req, res) => {
  if (!req.session.user) return res.status(401).json({ ok: false, msg: "Not logged in" });
  try {
    const cur = await cfFetch(`/dns_records/${req.params.id}`);
    const rec = cur?.result;
    if (!rec) return res.status(404).json({ ok: false, msg: "not_found" });
    if (!ownsName(req.session.user, rec.name?.toLowerCase())) return res.status(403).json({ ok: false, msg: "forbidden_outside_base" });

    const data = await cfFetch(`/dns_records/${req.params.id}`, { method: "DELETE" });
    if (data?.success) await appendLog({ type: "record_delete", by: req.session.user.username, detail: { id: req.params.id, name: rec.name } });
    res.json(data);
  } catch (err) {
    res.status(500).json({ ok: false, msg: err.message });
  }
});

// ----------- PAGES -----------
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "index.html")));
app.get("/dashboard", (req, res) => {
  if (!req.session.user) return res.redirect("/index.html");
  res.sendFile(path.join(__dirname, "dashboard.html"));
});

// Zone summary (like registrar "zone overview")
app.get("/api/zone", async (req, res) => {
  if (!req.session.user) return res.status(401).json({ ok: false, msg: "Not logged in" });
  try {
    const base = req.session.user.baseDomain?.toLowerCase();
    const list = await cfFetch(`/dns_records?per_page=1000`);
    const mine = (list?.result || []).filter(r => r.name?.toLowerCase() === base || r.name?.toLowerCase().endsWith(`.${base}`));
    const summary = {
      ok: true,
      baseDomain: base,
      count: mine.length,
      types: [...new Set(mine.map(r => r.type))],
    };
    res.json(summary);
  } catch (err) {
    res.status(500).json({ ok: false, msg: err.message });
  }
});

// Presets catalog (simple, neutral defaults)
app.get("/api/presets", (_req, res) => {
  res.json({
    ok: true,
    presets: [
      { key: "static", name: "Static site", desc: "A + www CNAME", records: [
        { type: "A", name: "@", content: "192.0.2.1", ttl: 300 },
        { type: "CNAME", name: "www", content: "@", ttl: 300 }
      ]},
      { key: "lms", name: "LMS", desc: "CNAME to LMS host", records: [
        { type: "CNAME", name: "@", content: "your-lms.example.com", ttl: 300 }
      ]},
      { key: "gateway", name: "Gateway", desc: "Redirect via TXT hint", records: [
        { type: "TXT", name: "@", content: "gateway=https://portal.example.org", ttl: 300 }
      ]}
    ]
  });
});

// Apply a preset under user's base (bulk create)
app.post("/api/presets/apply", async (req, res) => {
  if (!req.session.user) return res.status(401).json({ ok: false, msg: "Not logged in" });
  try {
    const { presetKey, at = "@", overrides = {} } = req.body || {};
    const catalog = {
      static: [
        { type: "A", name: "@", content: "192.0.2.1", ttl: 300 },
        { type: "CNAME", name: "www", content: "@", ttl: 300 }
      ],
      lms: [
        { type: "CNAME", name: "@", content: "your-lms.example.com", ttl: 300 }
      ],
      gateway: [
        { type: "TXT", name: "@", content: "gateway=https://portal.example.org", ttl: 300 }
      ]
    };
    const items = catalog[presetKey];
    if (!items) return res.status(400).json({ ok: false, msg: "unknown_preset" });

    const base = req.session.user.baseDomain;
    const prefix = String(at).trim() === "@" ? "" : `${String(at).trim()}.`;
    const created = [];
    for (const r of items) {
      const name = r.name === "@" ? `${prefix}${base}` : `${r.name}.${prefix}${base}`.replace(`..`, `.`);
      if (!ownsName(req.session.user, name)) return res.status(403).json({ ok: false, msg: "forbidden_outside_base" });
      const body = { ...r, ...overrides, name, proxied: false };
      const out = await cfFetch(`/dns_records`, { method: "POST", body: JSON.stringify(body) });
      if (!out?.success) return res.status(400).json(out);
      created.push(out.result);
      await appendLog({ type: "record_create", by: req.session.user.username, detail: { name: out.result?.name, type: out.result?.type } });
    }
    res.json({ ok: true, created });
  } catch (err) {
    res.status(500).json({ ok: false, msg: err.message });
  }
});

// ----------- START SERVER -----------
app.listen(PORT, () =>
  console.log(`✅ GACE Registrar running at http://localhost:${PORT}`)
);
