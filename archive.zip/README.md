# Gace-man-give-me-some-space
AHHHHHHHHHHHHHhHhHhHhHhHhHhHhHHhHhhHHhhH

## Environment
- ROOT_DOMAIN=gace.space
- CLOUDFLARE_ZONE_ID=...
- CLOUDFLARE_API_TOKEN=...
- SESSION_SECRET=...
- ENC_PASSPHRASE=... (AES-256-GCM for accounts)
- GITHUB_TOKEN=... (repo scope, private repo)
- GITHUB_REPO=owner/private-repo
- GITHUB_BRANCH=main

## Notes
- Each account owns one base subdomain (label.ROOT_DOMAIN). All records must be at or below it.
- Accounts and logs are AES-encrypted and stored in data/accounts.json and data/log.json in the private GitHub repo (local fallback if env is missing).
- On signup, an ownership TXT is created on the base subdomain.
- Endpoints:
  - GET /api/dns/check?name=host — includes ownerUsername if claimed.
  - GET /api/records — user-scoped list.
  - POST /api/records — create under your base; proxied is forced off.
  - PATCH/DELETE /api/records/:id — update/delete owned records.
  - GET /api/zone — zone summary for your base.
  - GET /api/presets — preset catalog.
  - POST /api/presets/apply — apply preset under your base.
